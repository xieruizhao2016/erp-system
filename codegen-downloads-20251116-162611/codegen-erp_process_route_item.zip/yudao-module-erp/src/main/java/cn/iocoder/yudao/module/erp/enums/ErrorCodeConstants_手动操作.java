// TODO 待办：请将下面的错误码复制到 yudao-module-erp 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== ERP 工艺路线明细 TODO 补充编号 ==========
ErrorCode PROCESS_ROUTE_ITEM_NOT_EXISTS = new ErrorCode(TODO 补充编号, "ERP 工艺路线明细不存在");