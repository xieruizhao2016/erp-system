<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="SKU编码" prop="skuCode">
        <el-input v-model="formData.skuCode" placeholder="请输入SKU编码" />
      </el-form-item>
      <el-form-item label="SKU名称" prop="skuName">
        <el-input v-model="formData.skuName" placeholder="请输入SKU名称" />
      </el-form-item>
      <el-form-item label="SKU描述" prop="description">
        <Editor v-model="formData.description" height="150px" />
      </el-form-item>
      <el-form-item label="状态：0-禁用，1-启用" prop="status">
        <el-radio-group v-model="formData.status">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="SKU条码" prop="barCode">
        <el-input v-model="formData.barCode" placeholder="请输入SKU条码" />
      </el-form-item>
      <el-form-item label="SKU图片URL" prop="imageUrl">
        <el-input v-model="formData.imageUrl" placeholder="请输入SKU图片URL" />
      </el-form-item>
      <el-form-item label="规格参数（JSON格式）" prop="specification">
        <el-input v-model="formData.specification" placeholder="请输入规格参数（JSON格式）" />
      </el-form-item>
      <el-form-item label="属性信息（JSON格式，如：颜色、尺寸等）" prop="attributes">
        <el-input v-model="formData.attributes" placeholder="请输入属性信息（JSON格式，如：颜色、尺寸等）" />
      </el-form-item>
      <el-form-item label="采购价格，单位：元" prop="purchasePrice">
        <el-input v-model="formData.purchasePrice" placeholder="请输入采购价格，单位：元" />
      </el-form-item>
      <el-form-item label="销售价格，单位：元" prop="salePrice">
        <el-input v-model="formData.salePrice" placeholder="请输入销售价格，单位：元" />
      </el-form-item>
      <el-form-item label="最低价格，单位：元" prop="minPrice">
        <el-input v-model="formData.minPrice" placeholder="请输入最低价格，单位：元" />
      </el-form-item>
      <el-form-item label="成本价格，单位：元" prop="costPrice">
        <el-input v-model="formData.costPrice" placeholder="请输入成本价格，单位：元" />
      </el-form-item>
      <el-form-item label="重量（kg）" prop="weight">
        <el-input v-model="formData.weight" placeholder="请输入重量（kg）" />
      </el-form-item>
      <el-form-item label="体积（m³）" prop="volume">
        <el-input v-model="formData.volume" placeholder="请输入体积（m³）" />
      </el-form-item>
      <el-form-item label="排序" prop="sort">
        <el-input v-model="formData.sort" placeholder="请输入排序" />
      </el-form-item>
      <el-form-item label="备注" prop="remark">
        <el-input v-model="formData.remark" placeholder="请输入备注" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { ProductSkuApi, ProductSku } from '@/api/erp/productsku'

/** ERP 产品SKU 表单 */
defineOptions({ name: 'ProductSkuForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  skuCode: undefined,
  skuName: undefined,
  description: undefined,
  status: undefined,
  barCode: undefined,
  imageUrl: undefined,
  specification: undefined,
  attributes: undefined,
  purchasePrice: undefined,
  salePrice: undefined,
  minPrice: undefined,
  costPrice: undefined,
  weight: undefined,
  volume: undefined,
  sort: undefined,
  remark: undefined
})
const formRules = reactive({
  skuCode: [{ required: true, message: 'SKU编码不能为空', trigger: 'blur' }],
  skuName: [{ required: true, message: 'SKU名称不能为空', trigger: 'blur' }],
  status: [{ required: true, message: '状态：0-禁用，1-启用不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await ProductSkuApi.getProductSku(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as ProductSku
    if (formType.value === 'create') {
      await ProductSkuApi.createProductSku(data)
      message.success(t('common.createSuccess'))
    } else {
      await ProductSkuApi.updateProductSku(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    skuCode: undefined,
    skuName: undefined,
    description: undefined,
    status: undefined,
    barCode: undefined,
    imageUrl: undefined,
    specification: undefined,
    attributes: undefined,
    purchasePrice: undefined,
    salePrice: undefined,
    minPrice: undefined,
    costPrice: undefined,
    weight: undefined,
    volume: undefined,
    sort: undefined,
    remark: undefined
  }
  formRef.value?.resetFields()
}
</script>