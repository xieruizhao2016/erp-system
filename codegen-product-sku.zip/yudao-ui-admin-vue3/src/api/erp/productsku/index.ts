import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** ERP 产品SKU信息 */
export interface ProductSku {
          id: number; // SKU编号
          skuCode?: string; // SKU编码
          skuName?: string; // SKU名称
          description: string; // SKU描述
          status?: number; // 状态：0-禁用，1-启用
          barCode: string; // SKU条码
          imageUrl: string; // SKU图片URL
          specification: string; // 规格参数（JSON格式）
          attributes: string; // 属性信息（JSON格式，如：颜色、尺寸等）
          purchasePrice: number; // 采购价格，单位：元
          salePrice: number; // 销售价格，单位：元
          minPrice: number; // 最低价格，单位：元
          costPrice: number; // 成本价格，单位：元
          weight: number; // 重量（kg）
          volume: number; // 体积（m³）
          sort: number; // 排序
          remark: string; // 备注
  }

// ERP 产品SKU API
export const ProductSkuApi = {
  // 查询ERP 产品SKU分页
  getProductSkuPage: async (params: any) => {
    return await request.get({ url: `/erp/product-sku/page`, params })
  },

  // 查询ERP 产品SKU详情
  getProductSku: async (id: number) => {
    return await request.get({ url: `/erp/product-sku/get?id=` + id })
  },

  // 新增ERP 产品SKU
  createProductSku: async (data: ProductSku) => {
    return await request.post({ url: `/erp/product-sku/create`, data })
  },

  // 修改ERP 产品SKU
  updateProductSku: async (data: ProductSku) => {
    return await request.put({ url: `/erp/product-sku/update`, data })
  },

  // 删除ERP 产品SKU
  deleteProductSku: async (id: number) => {
    return await request.delete({ url: `/erp/product-sku/delete?id=` + id })
  },

  /** 批量删除ERP 产品SKU */
  deleteProductSkuList: async (ids: number[]) => {
    return await request.delete({ url: `/erp/product-sku/delete-list?ids=${ids.join(',')}` })
  },

  // 导出ERP 产品SKU Excel
  exportProductSku: async (params) => {
    return await request.download({ url: `/erp/product-sku/export-excel`, params })
  }
}